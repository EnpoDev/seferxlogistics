<?php echo $__env->make('layouts.bayi', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php /**PATH /home/seferxlo/public_html/resources/views/components/bayi-layout.blade.php ENDPATH**/ ?>