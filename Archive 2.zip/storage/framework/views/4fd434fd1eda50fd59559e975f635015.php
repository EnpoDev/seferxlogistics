<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'name',
    'label' => null,
    'description' => null,
    'checked' => false,
    'disabled' => false,
    'error' => null,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'name',
    'label' => null,
    'description' => null,
    'checked' => false,
    'disabled' => false,
    'error' => null,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $isChecked = old($name, $checked);
?>

<div <?php echo e($attributes->only('class')); ?> x-data="{ checked: <?php echo e($isChecked ? 'true' : 'false'); ?> }">
    <label class="flex items-center justify-between gap-3 cursor-pointer <?php echo e($disabled ? 'cursor-not-allowed opacity-50' : ''); ?>">
        <div class="flex-1">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($label): ?>
                <span class="font-medium text-black dark:text-white"><?php echo e($label); ?></span>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($description): ?>
                <p class="text-sm text-gray-600 dark:text-gray-400 mt-1"><?php echo e($description); ?></p>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>

        <button
            type="button"
            role="switch"
            :aria-checked="checked"
            @click="checked = !checked"
            <?php if($disabled): ?> disabled <?php endif; ?>
            class="relative h-6 w-11 shrink-0 cursor-pointer rounded-full transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-gray-400 focus:ring-offset-2 <?php echo e($disabled ? 'cursor-not-allowed opacity-50' : ''); ?>"
            :class="checked ? 'bg-black dark:bg-white' : 'bg-gray-300 dark:bg-gray-700'"
        >
            <span
                class="absolute top-0.5 left-0.5 h-5 w-5 rounded-full bg-white dark:bg-gray-900 shadow-lg transition-transform duration-200"
                :class="checked ? 'translate-x-5' : 'translate-x-0'"
            ></span>
        </button>
        <input type="hidden" name="<?php echo e($name); ?>" :value="checked ? '1' : '0'">
    </label>

    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($error): ?>
        <p class="text-xs text-red-500 mt-1"><?php echo e($error); ?></p>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
</div>
<?php /**PATH /home/seferxlo/public_html/resources/views/components/form/toggle.blade.php ENDPATH**/ ?>