<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'amount' => null,
    'currency' => 'TL',
    'showSign' => false,
    'color' => null,
    'decimals' => 2,
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'amount' => null,
    'currency' => 'TL',
    'showSign' => false,
    'color' => null,
    'decimals' => 2,
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<?php
    $amount = $amount ?? 0;
    $formattedAmount = number_format((float)$amount, $decimals, ',', '.');

    // Renk belirleme
    if ($color) {
        $colorClass = match($color) {
            'success', 'green' => 'text-green-600 dark:text-green-400',
            'danger', 'red' => 'text-red-600 dark:text-red-400',
            'warning', 'yellow' => 'text-yellow-600 dark:text-yellow-400',
            'info', 'blue' => 'text-blue-600 dark:text-blue-400',
            default => 'text-black dark:text-white',
        };
    } elseif ($showSign && $amount != 0) {
        $colorClass = $amount > 0 ? 'text-green-600 dark:text-green-400' : 'text-red-600 dark:text-red-400';
    } else {
        $colorClass = 'text-black dark:text-white';
    }

    $sign = '';
    if ($showSign && $amount > 0) {
        $sign = '+';
    }
?>

<span <?php echo e($attributes->merge(['class' => $colorClass])); ?>>
    <?php echo e($sign); ?><?php echo e($formattedAmount); ?> <?php echo e($currency); ?>

</span>
<?php /**PATH /home/seferxlo/public_html/resources/views/components/data/money.blade.php ENDPATH**/ ?>